<div class="user-info-panel d-flex gap-12 align-items-center">
    <div class="user-img">
        <img src="{{ getFileLink('100x100',$subscribe->user->images) }}" alt="{{ $subscribe->user->first_name }}">
    </div>
</div>
