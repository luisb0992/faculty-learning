<p>Course ID : #GD5425</p>
<p>{{__('course_title')}} : {{ $enroll->enrollable->title  }}</p>
