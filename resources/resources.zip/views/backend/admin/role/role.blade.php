<div class="user-edit-panel">
    {{ $role->name }}
</div>
