<div class="user-info-panel d-flex gap-12 align-items-center">
    <div class="user-img">
        <img src="{{ getFileLink('40x40',$success_story->image) }}" alt="{{ $success_story->title }}">
    </div>
</div>
