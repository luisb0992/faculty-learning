<div class="user-info">
    <h6>{{ $payout->user->first_name }} {{ $payout->user->last_name }}</h6>
    <p>{{ $payout->user->email }}</p>
</div>
