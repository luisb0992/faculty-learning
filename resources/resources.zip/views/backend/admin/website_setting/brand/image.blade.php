<div class="user-info-panel d-flex gap-12 align-items-center">
    <div class="user-img">
        <img src="{{ getFileLink('195x34', $brand->logo) }}" alt="brand">
    </div>
</div>
