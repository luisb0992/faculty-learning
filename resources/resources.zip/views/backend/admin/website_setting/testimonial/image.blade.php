<div class="user-info-panel d-flex gap-12 align-items-center">
    <div class="user-img">
        <img src="{{ getFileLink('282x282',$testimonial->image) }}" alt="{{ $testimonial->title }}">
    </div>
</div>
