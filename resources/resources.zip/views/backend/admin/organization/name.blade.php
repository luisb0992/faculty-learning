<a href="{{ route('organizations.overview', $organization->id) }}">{{ $organization->org_name }}</a>
