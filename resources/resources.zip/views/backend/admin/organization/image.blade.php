<a href="{{ route('organizations.overview', $organization->id) }}">
    <img src="{{ getFileLink('68x48',  $organization->logo) }}" alt="{{__($organization->org_name) }}">
</a>
