<div action="#" class="user-password">
    <input class="passField" type="password" id="password_{{ $apiKey->id }}" readonly value="{{ $apiKey->key }}">
    <label for="password_{{ $apiKey->id }}" class="toggle-password"><i class="lar la-eye"></i></label>
  </div>
