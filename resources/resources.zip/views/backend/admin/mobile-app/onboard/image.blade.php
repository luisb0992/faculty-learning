<div class="app-img">
    <img src="{{ getFileLink('68x48',  $onboard->image) }}" alt="{{ $onboard->title }}">
</div>
