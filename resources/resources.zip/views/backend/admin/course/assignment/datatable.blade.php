{{ $dataTable->table() }}

{{ $dataTable->script() }}
