<div class="user-info-panel d-flex gap-12 align-items-center">
    <div class="user-img">
        <img src="{{ getFileLink('40x40',$category->image) }}" alt="{{ $category->title }}">
    </div>
</div>
