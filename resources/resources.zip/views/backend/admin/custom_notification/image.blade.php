<div class="app-img">
    <img src="{{ getFileLink('40x40',$notification->image) }}" alt="{{ $notification->title }}">
</div>
