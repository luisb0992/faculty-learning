<img src="{{ getFileLink('80x80',$offline_method->image) }}" alt="{{ $offline_method->name }}">
