<div class="text-start">
    @foreach($instructors as $instructor)
        <p>{{ $instructor->name }}</p>
    @endforeach
</div>
